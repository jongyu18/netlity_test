function memberChk() {
	if (document.formm.id.value == "") {
		alert("아이디를 입력하여 주세요.");
		document.formm.id.focus();
	
	} else if (document.formm.pwss.value == "") {
		alert("비밀번호를 입력해 주세요.");
		document.formm.pwss.focus();
	} else if ((document.formm.pwss.value != document.formm.pwdCheck.value)) {
		alert("비밀번호가 일치하지 않습니다.");
		document.formm.pwss.focus();
	} else if (document.formm.name.value == "") {
		alert("이름을 입력해 주세요.");
		document.formm.name.focus();
	} else if (document.formm.email.value == "") {
		alert("이메일을 입력해 주세요.");
		document.formm.email.focus();
	} else {
		document.formm.action = "NonageServlet?command=join";
		document.formm.submit();
	}
}